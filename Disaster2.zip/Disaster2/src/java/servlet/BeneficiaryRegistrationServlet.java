package servlet;

import bean.BeneficiaryBean; // Import the updated BeneficiaryBean
import dao.BeneficiaryDao;   // Import the updated BeneficiaryDao

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher; // For forwarding requests

@WebServlet("/BeneficiaryRegistrationServlet")
public class BeneficiaryRegistrationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Retrieve parameters from the request, matching new field names
        String beneficiaryId = request.getParameter("beneficiaryId");
        String beneficiaryName = request.getParameter("beneficiaryName");
        String icNumber = request.getParameter("icNumber");
        String address = request.getParameter("address");
        String contactNumber = request.getParameter("contactNumber"); // New field
        String dateOfBirth = request.getParameter("dateOfBirth");     // Renamed field

        // Create a BeneficiaryBean object and populate it
        BeneficiaryBean beneficiaryBean = new BeneficiaryBean();
        beneficiaryBean.setBeneficiaryId(beneficiaryId);
        beneficiaryBean.setBeneficiaryName(beneficiaryName);
        beneficiaryBean.setIcNumber(icNumber);
        beneficiaryBean.setAddress(address);
        beneficiaryBean.setContactNumber(contactNumber);
        beneficiaryBean.setDateOfBirth(dateOfBirth);

        // Use BeneficiaryDao for database operations
        BeneficiaryDao beneficiaryDao = new BeneficiaryDao();
        boolean success = false;
        String action = request.getParameter("action"); // Get the action (e.g., "update")

        try {
            if ("update".equals(action)) {
                // This is an update operation
                // Check if the IC Number is already taken by another beneficiary
                if (beneficiaryDao.isIcNumberTakenByOtherBeneficiary(icNumber, beneficiaryId)) {
                    request.setAttribute("errorMessage", "IC Number '" + icNumber + "' is already registered to another beneficiary.");
                    RequestDispatcher dispatcher = request.getRequestDispatcher("/editBeneficiaryInformation.jsp?id=" + beneficiaryId);
                    dispatcher.forward(request, response);
                    return; // Stop further processing
                }

                // If IC number is unique or unchanged, proceed with update
                success = beneficiaryDao.updateBeneficiary(beneficiaryBean);
                if (success) {
                    response.sendRedirect(request.getContextPath() + "/beneficiaryInformation.jsp?status=updated");
                } else {
                    request.setAttribute("errorMessage", "Beneficiary update failed. Please try again.");
                    RequestDispatcher dispatcher = request.getRequestDispatcher("/editBeneficiaryInformation.jsp?id=" + beneficiaryId);
                    dispatcher.forward(request, response);
                }
            } else {
                // This is a new registration (insert operation)
                // You might want to add a check for duplicate IC_NUMBER here too for new registrations
                if (beneficiaryDao.isIcNumberExists(icNumber)) { // Assuming isIcNumberExists method in DAO
                    request.setAttribute("errorMessage", "IC Number '" + icNumber + "' is already registered.");
                    RequestDispatcher dispatcher = request.getRequestDispatcher("/registerBeneficiary.jsp");
                    dispatcher.forward(request, response);
                    return;
                }

                success = beneficiaryDao.registerBeneficiary(beneficiaryBean);
                if (success) {
                    response.sendRedirect(request.getContextPath() + "/beneficiaryInformation.jsp?status=success");
                } else {
                    request.setAttribute("errorMessage", "Beneficiary registration failed. Please try again.");
                    RequestDispatcher dispatcher = request.getRequestDispatcher("/registerBeneficiary.jsp");
                    dispatcher.forward(request, response);
                }
            }
        } catch (SQLException e) {
            System.err.println("Database error during beneficiary operation: " + e.getMessage());
            e.printStackTrace(); // Log the exception for troubleshooting
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            // Redirect based on action
            if ("update".equals(action)) {
                RequestDispatcher dispatcher = request.getRequestDispatcher("/editBeneficiaryInformation.jsp?id=" + beneficiaryId);
                dispatcher.forward(request, response);
            } else {
                RequestDispatcher dispatcher = request.getRequestDispatcher("/registerBeneficiary.jsp");
                dispatcher.forward(request, response);
            }
        } catch (Exception e) {
            System.err.println("An unexpected error occurred during beneficiary operation: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("errorMessage", "An unexpected error occurred: " + e.getMessage());
            // Redirect based on action
            if ("update".equals(action)) {
                RequestDispatcher dispatcher = request.getRequestDispatcher("/editBeneficiaryInformation.jsp?id=" + beneficiaryId);
                dispatcher.forward(request, response);
            } else {
                RequestDispatcher dispatcher = request.getRequestDispatcher("/registerBeneficiary.jsp");
                dispatcher.forward(request, response);
            }
        }
    }
}
