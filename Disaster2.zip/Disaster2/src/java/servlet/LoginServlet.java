package servlet;

import bean.LoginBean; // Import the updated LoginBean
import dao.LoginDao;   // Import the updated LoginDao

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException; // Import SQLException for specific handling
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // No need for a PreparedStatement field here, as DAO handles it.
    // The init() method can be removed or left empty if no specific servlet initialization is needed.

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        LoginDao loginDao = new LoginDao(); // Instantiate the DAO

        try {
            if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
                sendAlert(out, "Username and password are required.", "login.jsp");
                return;
            }

            if (loginDao.validateLogin(username, password)) { // Use DAO for validation
                HttpSession session = request.getSession();
                session.setAttribute("user", username); // Store username in session

                response.sendRedirect("dashboard.jsp"); // Redirect to a new dashboard or main page
            } else {
                sendAlert(out, "Invalid username or password. Please try again.", "login.jsp");
            }
        } catch (SQLException ex) {
            // Log the SQL exception for debugging
            System.err.println("Database error during login: " + ex.getMessage());
            ex.printStackTrace();
            sendAlert(out, "A database error occurred. Please try again later.", "login.jsp");
        } catch (Exception ex) {
            // Catch any other unexpected exceptions
            System.err.println("An unexpected error occurred during login: " + ex.getMessage());
            ex.printStackTrace();
            sendAlert(out, "An unexpected error occurred. Please try again later.", "login.jsp");
        } finally {
            out.close();
        }
    }

    // Helper method to send JavaScript alert and redirect
    private void sendAlert(PrintWriter out, String message, String redirectPage) {
        out.println("<html><body>");
        out.println("<script>");
        out.println("alert('" + message + "');");
        out.println("window.location.href='" + redirectPage + "';");
        out.println("</script>");
        out.println("</body></html>");
    }
}